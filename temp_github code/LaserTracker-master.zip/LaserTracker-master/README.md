# LaserTracker
Laser tracker made with OpenCV and numPy.

- Curso: Engenharia de Computação (Computer Engineering)
- Cadeira: Sistemas Gráficos
- Professor: Ricardo Nagel

- Autor: Lucas Ribeiro

---

Siga-me no linkedin: @luucasrb

# Laser_Tracker
Python and OpenCV program to track a laser spot on a screen.
This program converts the video frames into grayscale and then finds the centroid of the laser spot. Coordinates in 'x' and 'y' are then output to the terminal. 
